A Blood bank website made using MERN Stack.
The UI is made with the help of Youtube Videos but backend and new features are added solely by me.
Example : Showing whole transaction of Blood.

![image](https://github.com/user-attachments/assets/0b4451da-f1e6-4553-b811-094328c8c526)

![image](https://github.com/user-attachments/assets/ee6edfb2-6e7a-43b9-8ebf-bafdd98bb8c4)

![image](https://github.com/user-attachments/assets/c18115d5-07a0-4f83-b1e6-4caf308fb53e)

